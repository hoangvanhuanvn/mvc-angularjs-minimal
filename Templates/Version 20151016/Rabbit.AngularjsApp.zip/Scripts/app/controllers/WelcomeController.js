﻿'use strict';

(function (angular) {
    var app = angular.module('app');
    app.controller('WelcomeController', ['$scope', function ($scope) {

    }]);
})(angular);
