﻿'use strict';

(function (angular) {
    var app = angular.module('app');
    app.controller('TestController', ['$scope', function ($scope) {
        
    }]);
})(angular);
