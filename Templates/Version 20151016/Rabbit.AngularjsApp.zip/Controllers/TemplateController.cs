﻿using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class TemplateController : ControllerBase
    {
        public ActionResult Welcome()
        {
            ViewBag.WebpagesVersion = Configuration.Get("webpages:Version");
            return PartialView();
        }

        public ActionResult Test()
        {
            return PartialView();
        }
    }
}