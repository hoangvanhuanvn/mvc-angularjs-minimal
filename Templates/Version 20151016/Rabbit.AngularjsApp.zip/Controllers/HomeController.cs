﻿using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class HomeController : ControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
