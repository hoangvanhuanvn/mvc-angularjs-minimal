﻿Rabbit AngularJS Client Template

1. After app started, it gets into WelcomeController through configuration in the routeProvider

2. Modify url, add test at the end, it will navigate to another page
